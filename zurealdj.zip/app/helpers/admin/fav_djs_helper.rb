module Admin::FavDjsHelper
end
