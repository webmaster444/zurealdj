class MessagesController < ApplicationController

end